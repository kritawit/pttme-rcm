<table border="1" style="width:100%">
<tboby>
    <tr>
      <td class="cell2" height="50" bgcolor="{{$step2->description}}">
      {{$step2->ref1}}
      </td>
    <tr>
</tboby>
</table>