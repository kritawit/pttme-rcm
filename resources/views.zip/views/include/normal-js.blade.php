    {!! HTML::script('public/plugins/jQuery/jQuery-2.1.4.min.js') !!}
    {!! HTML::script('public/easyui/jquery.min.js') !!}
    {!! HTML::script('public/js/jquery-ui.min.js') !!}
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    {!! HTML::script('public/bootstrap/js/bootstrap.min.js') !!}
    {!! HTML::script('public/plugins/datatables/jquery.dataTables.min.js') !!}
    {!! HTML::script('public/plugins/select2/select2.full.min.js') !!}
    {!! HTML::script('public/js/raphael-min.js') !!}
    {!! HTML::script('public/plugins/sparkline/jquery.sparkline.min.js') !!}
    {!! HTML::script('public/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js') !!}
    {!! HTML::script('public/plugins/jvectormap/jquery-jvectormap-world-mill-en.js') !!}
    {!! HTML::script('public/plugins/knob/jquery.knob.js') !!}
    {!! HTML::script('public/js/moment.min.js') !!}
    {!! HTML::script('public/plugins/daterangepicker/daterangepicker.js') !!}
    {!! HTML::script('public/plugins/datepicker/bootstrap-datepicker.js') !!}
    {!! HTML::script('public/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js') !!}
    {!! HTML::script('public/plugins/slimScroll/jquery.slimscroll.min.js') !!}
    {!! HTML::script('public/plugins/fastclick/fastclick.min.js') !!}
    {!! HTML::script('public/dist/js/app.min.js') !!}
    {!! HTML::script('public/dist/js/demo.js') !!}

    
